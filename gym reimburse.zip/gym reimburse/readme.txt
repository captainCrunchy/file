
=== 2018 Gym fees ===

New York Sports Club (NYSC), paid using TD Checking account
	292.42

Club Metro, paid using Venture Credit Card
	242.50

TOTAL - 534.92


=== STATEMENTS ===

January

(none)


February

(none)


March

  NYSC
	NYSC BUTLER - 5.33 (3/26/18) [TD Bank 2018-04-11.pdf]


April

  NYSC
	NYSC BUTLER - 39.44 (4/2/18) [TD Bank 2018-04-11.pdf]
	NYSC BUTLER - 74.63 (4/16/18) [TD Bank 2018-05-11.pdf]


May

  NYSC
	NYSC BUTLER - 39.44 (5/2/18) [TD Bank 2018-05-11.pdf]


June

  NYSC
	NYSC BUTLER - 39.44 (6/4/18) [TD Bank 2018-06-11.pdf]


July

  NYSC
	NYSC BUTLER - 39.44 (7/2/18) [TD Bank 2018-07-11.pdf]


August

  NYSC
	NYSC BUTLER - 39.44 (8/2/18) [TD Bank 2018-08-11.pdf]


September

  NYSC
	NYSC BUTLER - 5.26 (9/4/18) [TD Bank 2018-09-11.pdf]
	NYSC BUTLER - 10.00 (9/6/18) [TD Bank 2018-09-11.pdf]

  Club Metro
	ABC*Club Metro - 74.62 (9/10/18) [Venture 2018-10-05.pdf]
	ABC*Club Metro - 9.99 (9/20/18) [Venture 2018-10-05.pdf]


October

  Club Metro
	ABC*Club Metro - 52.63 (10/10/18) [Venture 2018-11-05.pdf]


November

  Club Metro
	ABC*Club Metro - 52.63 (11/10/18) [Venture 2018-12-05.pdf]


December

  Club Metro
	ABC*Club Metro - 52.63 (12/10/18) [Venture 2019-01-05.pdf]
